let greeting: string = 'Hello from Skillsoft!';
console.log(greeting);
export {};
